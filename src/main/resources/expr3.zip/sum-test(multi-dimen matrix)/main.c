#include <stdio.h>
int main(){
    int n ;
    scanf("%d",&n);
    int k[n];

    int i = 0;
    int sum = 0;
    while(++i <= n * n * n){
        sum = sum + i;
        printf("%d\n",i);
    }

    printf("sum:%d",sum);
}
